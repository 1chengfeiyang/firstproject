var group___d_a_p___config___information__gr =
[
    [ "CPU_CLOCK", "group___d_a_p___config___information__gr.html#ga512016e5f1966a8fd45b3f1a81ba5b8f", null ],
    [ "DAP_FW_VER", "group___d_a_p___config___information__gr.html#ga2ddfb06f0731ff46fed4eadf1af66c71", null ],
    [ "DAP_JTAG", "group___d_a_p___config___information__gr.html#ga3bbd310146b348db48a842ee804a0adf", null ],
    [ "DAP_JTAG_DEV_CNT", "group___d_a_p___config___information__gr.html#gab29200a0988c7d1454f63661a8450dbf", null ],
    [ "DAP_PACKET_COUNT", "group___d_a_p___config___information__gr.html#ga03ed6a5aae34f4379ea97435122f83dd", null ],
    [ "DAP_PACKET_SIZE", "group___d_a_p___config___information__gr.html#gaa28bb1da2661291634c4a8fb3e227404", null ],
    [ "DAP_PRODUCT", "group___d_a_p___config___information__gr.html#ga0828bced851517840ea292a8ed7d705e", null ],
    [ "DAP_SER_NUM", "group___d_a_p___config___information__gr.html#ga63fd6cfbbace96b6a092868eb8d9fc41", null ],
    [ "DAP_SWD", "group___d_a_p___config___information__gr.html#gaf886ab35e52d1ff2935351817786c8af", null ],
    [ "DAP_VENDOR", "group___d_a_p___config___information__gr.html#gab9d05c1024cd4d0ab748382fe6756052", null ],
    [ "IO_PORT_WRITE_CYCLES", "group___d_a_p___config___information__gr.html#ga119c70409a24e3a8bb35df07dffeb8c8", null ]
];