#ifdef STM32F1xx
#include "stm32f1xx_hal_gpio_ex.c"
#endif
