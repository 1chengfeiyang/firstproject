#ifdef STM32G4xx
#include "stm32g4xx_hal_fmac.c"
#endif
