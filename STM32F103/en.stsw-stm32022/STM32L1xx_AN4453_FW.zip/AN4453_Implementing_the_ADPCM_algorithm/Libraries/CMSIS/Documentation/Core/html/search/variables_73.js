var searchData=
[
  ['scr',['SCR',['../struct_s_c_b___type.html#abfad14e7b4534d73d329819625d77a16',1,'SCB_Type']]],
  ['shcsr',['SHCSR',['../struct_s_c_b___type.html#ae9891a59abbe51b0b2067ca507ca212f',1,'SCB_Type']]],
  ['shp',['SHP',['../struct_s_c_b___type.html#af6336103f8be0cab29de51daed5a65f4',1,'SCB_Type']]],
  ['sleepcnt',['SLEEPCNT',['../struct_d_w_t___type.html#a8afd5a4bf994011748bc012fa442c74d',1,'DWT_Type']]],
  ['sppr',['SPPR',['../struct_t_p_i___type.html#a3eb655f2e45d7af358775025c1a50c8e',1,'TPI_Type']]],
  ['spsel',['SPSEL',['../union_c_o_n_t_r_o_l___type.html#a8cc085fea1c50a8bd9adea63931ee8e2',1,'CONTROL_Type']]],
  ['sspsr',['SSPSR',['../struct_t_p_i___type.html#a158e9d784f6ee6398f4bdcb2e4ca0912',1,'TPI_Type']]],
  ['stir',['STIR',['../struct_n_v_i_c___type.html#a0b0d7f3131da89c659a2580249432749',1,'NVIC_Type']]],
  ['systemcoreclock',['SystemCoreClock',['../group__system__init__gr.html#gaa3cd3e43291e81e795d642b79b6088e6',1,'Ref_SystemAndClock.txt']]]
];
