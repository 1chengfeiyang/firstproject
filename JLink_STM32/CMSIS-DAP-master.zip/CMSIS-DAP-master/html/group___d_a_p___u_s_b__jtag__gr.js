var group___d_a_p___u_s_b__jtag__gr =
[
    [ "DAP_JTAG_Sequence", "group___d_a_p___u_s_b__jtag__sequence.html", null ],
    [ "DAP_JTAG_Configure", "group___d_a_p___u_s_b__jtag__configure.html", null ],
    [ "DAP_JTAG_IDCODE", "group___d_a_p___u_s_b__jtag__idcode.html", null ]
];