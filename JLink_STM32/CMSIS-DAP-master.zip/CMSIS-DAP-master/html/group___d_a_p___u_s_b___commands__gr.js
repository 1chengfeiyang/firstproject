var group___d_a_p___u_s_b___commands__gr =
[
    [ "General Commands", "group___d_a_p___u_s_b__gen_commands__gr.html", "group___d_a_p___u_s_b__gen_commands__gr" ],
    [ "Transfer Commands", "group___d_a_p___u_s_b__transfer__gr.html", "group___d_a_p___u_s_b__transfer__gr" ],
    [ "Common SWD/JTAG Commands", "group___d_a_p___u_s_b__swj__gr.html", "group___d_a_p___u_s_b__swj__gr" ],
    [ "SWD Commands", "group___d_a_p___u_s_b__swd__gr.html", "group___d_a_p___u_s_b__swd__gr" ],
    [ "JTAG Commands", "group___d_a_p___u_s_b__jtag__gr.html", "group___d_a_p___u_s_b__jtag__gr" ],
    [ "Response Status", "group___d_a_p___reponses___status.html", null ]
];