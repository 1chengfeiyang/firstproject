#ifdef STM32G4xx
#include "stm32g4xx_ll_fmac.c"
#endif
