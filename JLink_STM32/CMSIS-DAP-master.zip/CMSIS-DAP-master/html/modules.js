var modules =
[
    [ "Firmware Configuration", "group___d_a_p___config__gr.html", "group___d_a_p___config__gr" ],
    [ "Validate Debug Unit", "group___d_a_p___validate__gr.html", null ],
    [ "CMSIS-DAP Commands", "group___d_a_p___commands__gr.html", "group___d_a_p___commands__gr" ],
    [ "CMSIS-DAP Vendor Commands", "group___d_a_p___vendor__gr.html", "group___d_a_p___vendor__gr" ]
];