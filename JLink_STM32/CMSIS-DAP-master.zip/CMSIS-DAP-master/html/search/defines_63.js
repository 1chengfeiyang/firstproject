var searchData=
[
  ['cpu_5fclock',['CPU_CLOCK',['../_d_a_p__config_8c.html#a512016e5f1966a8fd45b3f1a81ba5b8f',1,'CPU_CLOCK():&#160;DAP_config.c'],['../_d_a_p__config_8h.html#a512016e5f1966a8fd45b3f1a81ba5b8f',1,'CPU_CLOCK():&#160;DAP_config.h']]]
];
