var group___d_a_p___config___debug__gr =
[
    [ "CPU_CLOCK", "group___d_a_p___config___debug__gr.html#ga512016e5f1966a8fd45b3f1a81ba5b8f", null ],
    [ "DAP_DEFAULT_PORT", "group___d_a_p___config___debug__gr.html#ga89462514881c12c1508395050ce160eb", null ],
    [ "DAP_DEFAULT_SWJ_CLOCK", "group___d_a_p___config___debug__gr.html#gab52710df89c3e3c19de577c638f954ea", null ],
    [ "DAP_JTAG", "group___d_a_p___config___debug__gr.html#ga3bbd310146b348db48a842ee804a0adf", null ],
    [ "DAP_JTAG_DEV_CNT", "group___d_a_p___config___debug__gr.html#gab29200a0988c7d1454f63661a8450dbf", null ],
    [ "DAP_PACKET_COUNT", "group___d_a_p___config___debug__gr.html#ga03ed6a5aae34f4379ea97435122f83dd", null ],
    [ "DAP_PACKET_SIZE", "group___d_a_p___config___debug__gr.html#gaa28bb1da2661291634c4a8fb3e227404", null ],
    [ "DAP_SWD", "group___d_a_p___config___debug__gr.html#gaf886ab35e52d1ff2935351817786c8af", null ],
    [ "IO_PORT_WRITE_CYCLES", "group___d_a_p___config___debug__gr.html#ga119c70409a24e3a8bb35df07dffeb8c8", null ],
    [ "TARGET_DEVICE_FIXED", "group___d_a_p___config___debug__gr.html#ga792651aa4035a7ad712c6bb201db8a6a", null ]
];