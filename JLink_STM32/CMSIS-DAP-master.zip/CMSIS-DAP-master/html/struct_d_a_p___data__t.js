var struct_d_a_p___data__t =
[
    [ "clock_delay", "struct_d_a_p___data__t.html#a867e32aceeebe72a1cc427da08610cb7", null ],
    [ "data_phase", "struct_d_a_p___data__t.html#a22cf6ad6a88976cfde8ffdc11642e551", null ],
    [ "debug_port", "struct_d_a_p___data__t.html#a6941ac1271b8a22b46f3b658a3229210", null ],
    [ "fast_clock", "struct_d_a_p___data__t.html#a1697be6fa7b2589854c51573d71271af", null ],
    [ "idle_cycles", "struct_d_a_p___data__t.html#a78d595fbd5503736d46194b746c6bae6", null ],
    [ "match_mask", "struct_d_a_p___data__t.html#aca29d7039a8eee711787e4de616e2370", null ],
    [ "match_retry", "struct_d_a_p___data__t.html#a8c4cbd92518547de8bb34b5ec3acf99b", null ],
    [ "retry_count", "struct_d_a_p___data__t.html#ae663822935220bf08f2cfd7f41629bae", null ],
    [ "transfer", "struct_d_a_p___data__t.html#a91bc0c1e81527aaa457d0dde4b01021c", null ],
    [ "turnaround", "struct_d_a_p___data__t.html#a1d3ca0f5d45cfe1526d3c58577671758", null ]
];