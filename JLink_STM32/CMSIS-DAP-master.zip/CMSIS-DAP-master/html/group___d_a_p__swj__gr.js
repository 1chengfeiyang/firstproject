var group___d_a_p__swj__gr =
[
    [ "DAP_SWJ_Pins", "group___d_a_p___s_w_j___pins.html", null ],
    [ "DAP_SWJ_Clock", "group___d_a_p___s_w_j___clock.html", null ],
    [ "DAP_SWJ_Sequence", "group___d_a_p___s_w_j___sequence.html", null ]
];