#ifdef STM32H7xx
#include "stm32h7xx_hal_mdma.c"
#endif
#ifdef STM32MP1xx
#include "stm32mp1xx_hal_mdma.c"
#endif
